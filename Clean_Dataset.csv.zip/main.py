import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# modles used 
import xgboost as xgb
from sklearn.ensemble import RandomForestRegressor as rfr

from sklearn.metrics import mean_absolute_error,mean_squared_error,r2_score, accuracy_score

# ----- data importing -------

df= pd.read_csv('C:/Users/tempuser02/Desktop/flight fare predict/Clean_Dataset.csv',nrows=50000)

# ----- data pre processing ------

airline_map = {'Air_India':0,'AirAsia':1,'GO_FIRST':2,'Indigo':3,'SpiceJet':4,'Vistara':5}
df['airline'] = df['airline'].replace(airline_map).astype(int)

location_map = {'Bangalore':0,'Chennai':1,'Delhi':2,'Hyderabad':3,'Kolkata':4,'Mumbai':5}
df['source_city'] = df['source_city'].replace(location_map).astype(int)
df['destination_city'] = df['destination_city'].replace(location_map).astype(int)

time_map = {'Afternoon':0,'Early_Morning':1,'Evening':2,'Late_Night':3,'Morning':4,'Night':5}
df['departure_time'] = df['departure_time'].replace(time_map).astype(int)
df['arrival_time'] = df['arrival_time'].replace(time_map).astype(int)

stops_map = {'zero':0,'one':1,'two_or_more':2}
df['stops'] = df['stops'].replace(stops_map).astype(int)

df['class'] = df['class'].replace({'Economy':0, 'Business':1})

df['duration'] = (df['duration']*60).astype(int)

df = df.drop('flight',axis=1)

# -------- standard scaling price ----------------

scale=StandardScaler()
df['duration'] = scale.fit_transform(df[['duration']])

# -------- train test split ----------------------

X = df.drop('price',axis=1)
y = df['price']
X_train , X_test , y_train , y_test = train_test_split(X , y , test_size = 0.3 , random_state = 42)

# -------- model training --------------------------

model_xgb = xgb.XGBRegressor(n_estimators=1000, learning_rate=0.05, n_jobs=-1,random_state=42)
model_xgb.fit(X_train,y_train)

model_rfr = rfr(n_estimators=1000,n_jobs=-1,random_state=42)
model_rfr.fit(X_train,y_train)

# --------- model testing ---------------------------

list_of_models = [[model_xgb,'xgboost'],[model_rfr,'RandomforestRegressor']]
def model(model,name):
    print(f"------------- model - {name} ----------------------------\n")
    y_pred = model.predict(X_test)

    mse = np.sqrt(mean_squared_error(y_test,y_pred))
    print(f"The mean squared error for {name} is : \n",mse)

    r2 = r2_score(y_test,y_pred)
    print(f"The R square value of {name} is : \n",r2)

    mae = mean_absolute_error(y_test,y_pred)
    print(f"The mean abolute error for {name} is : \n",mae)
    
    print("\n-----------------------------------------------------------")

for x in list_of_models:
    model(x[0],x[1])
    
#------------ user input part --------------------------

user_airline = input("Enter airline name : ")
user_source = input("Enter start location : ")
user_dest = input("Enter destination : ")
user_departure = input("Enter departure time : ")
user_stops = input("Enter no. of stops : ")
user_arrival = input("Enter arrival time : ")
user_class = input("Enter class of journey : ")
user_duration = float(input("Enter duration of travel : "))
user_daysleft = int(input("Enter the no of days left for booking the ticket : "))

user_data = {'airline':[user_airline],'source_city':[user_source],'departure_time':[user_departure],
'stops':[user_stops],'arrival_time':[user_arrival],'destination_city':[user_dest],'class':[user_class],
'duration':[user_duration],'days_left':[user_daysleft]}

user_df = pd.DataFrame(user_data)

user_df['airline'] = user_df['airline'].replace(airline_map).astype(int)
user_df['source_city'] = user_df['source_city'].replace(location_map).astype(int)
user_df['destination_city'] = user_df['destination_city'].replace(location_map).astype(int)
user_df['departure_time'] = user_df['departure_time'].replace(time_map).astype(int)
user_df['arrival_time'] = user_df['arrival_time'].replace(time_map).astype(int)
user_df['stops'] = user_df['stops'].replace(stops_map).astype(int)
user_df['class'] = user_df['class'].replace({'Economy':0,'Business':1})
user_df['duration'] = (user_df['duration']*60).astype(int)

user_predict_rfr = model_rfr.predict(user_df)
user_predict_xgb = model_xgb.predict(user_df)
print("--------------------------- TARIFF PREDICTION --------------------------\n")
print("Price predicted by randomforest : ",user_predict_rfr)
print("Price predcited by XGB : ",user_predict_xgb)
print("\n--------------------------------------------------------------------------")